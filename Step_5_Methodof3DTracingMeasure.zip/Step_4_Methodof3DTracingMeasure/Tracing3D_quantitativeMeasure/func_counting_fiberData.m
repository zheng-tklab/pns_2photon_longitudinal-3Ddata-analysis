% 2011-
% {hongwei.zheng,kuner}@uni-heidelberg.de
%

function  []= func_counting_fiberData(pathm, mice1, folder, result_folder)

pathName =strcat(pathm, result_folder); 
writefolder =strcat(pathName, '\');
writepath2 =strcat(writefolder,'cleaned','\');
writename2 = strcat(writepath2, mice1, '_', folder,'\');
mkdir(writename2);
writename1 = strcat(writepath2, mice1,'\');
mkdir(writename1);


pathall = strcat(pathm,mice1,'', folder,'\');
imgType ='.tif';
Img_basal = dir([pathall, '*',imgType]);
NumImg_basal = size(Img_basal,1);


fileIDNum6= fopen(strcat(writename1, mice1, '_number of TerminalsAll a+b','.dat'), 'a+'); 
fprintf(fileIDNum6, '%s%s:, %s,  %s,  %s, %s,  %s \n', 'Img_basal.name', '_number of all Terminals a+b', 'numOb', 'voxelSize', 'all_terminals', 'terminalLength', 'density');


for ii=1:NumImg_basal   
    
    img_basal_Name = strcat(pathall,  Img_basal(ii).name)
    FileTif=img_basal_Name;
    InfoImage=imfinfo(FileTif);
    mImage=InfoImage(1).Width;
    nImage=InfoImage(1).Height;
    duration=length(InfoImage);
    num_images = numel(InfoImage);
    V1s=zeros(nImage, mImage, duration, 'uint8');
    V2f=zeros(nImage, mImage, duration, 'uint8');
%             
            for number_list = 1:duration
                    im = imread(FileTif,number_list, 'Info',InfoImage);    %%figure(1);  imshow(im); title('im');
                   im1 = 255-im;
                     im1spbw = im2bw(im1);     %   figure(2), imshow(im1spbw); title('Iobrcbr1 bw')
                      V1s(:,:,number_list)  = im1spbw;
%                 V2_skel(:,:,number_list) = Iskel;
%                 Iskel3p = imdilate(Iskel, strel('disk',2)); 
%                 V2_3p(:,:,number_list) = Iskel3p;
     
            end
 %%    %% remove noise
            V_sp = V1s;
            [x,y,z] =size(V_sp);
           %%  se3d= strel('ball', 1, 1); 
             %%V_sp2 = imdilate (uint8(V_sp*255), se3d) ; 
         
            V_sp2 = uint8(V_sp*255);                        
            CC = bwconncomp(V_sp2);            
                                     % get all particles
            numPixels = cellfun(@numel,CC.PixelIdxList);
            [idx_small_all]= find([numPixels] <2);                %mean([numPixels]
             %BW_big = ismember(V2, idx_big); 
             duration = length([idx_small_all]);
            for k = 1: duration
                kk = idx_small_all(k);
                  %  areas_in_pixels(kk)=length(CC.PixelIdxList{k});
                  %  areas_in_pixels(kk)=length(CC.PixelIdxList{kk});
                idx =CC.PixelIdxList{kk};
                V_sp2(idx) =0;
            end
            
            CC2 = bwconncomp(V_sp2);       
            numOb = CC2.NumObjects;      
            max_im1_all   = max(V_sp2, [],3);
         %   figure, imshow(max_im1_all);  title('mip imfiber and spineTogether, imdliate3D1');
            imwrite (max_im1_all, sprintf('%s%s%s%s%s',  writename2,'mip_', Img_basal(ii).name, '_max_im1_all','.tif' ), 'tiff'); 
             
            for i = 1:z
                Iv1 = V_sp2(:,:,i);
                %%figure(4); imshow(Iv1); title('after modify1');
                imwrite (Iv1, sprintf('%s%s%s%s',   writename2, Img_basal(ii).name, '_withSpineStack_AfterDilate3D_', imgType), 'WriteMode', 'append');
            end
           
%%  clean the individual terminals, only the biggest is there
           V_delta = V_sp2;
            CC3 = bwconncomp(V_delta);    % get all particles
            numPixels = cellfun(@numel,CC3.PixelIdxList);
            [biggest,idx] = max(numPixels);
         %%%   [idx_big]= find( [numPixels] > mean([numPixels]));
           [idx_small_all]= find([numPixels] <mean([numPixels])); %mean([numPixels]
            %BW_big = ismember(V2, idx_big); 
            [x,y,z] =size(V_delta);
             V_onlySp  = V_delta;
            duration = length([idx_small_all]);
            for k = 1: duration
                kk = idx_small_all(k);
                  %  areas_in_pixels(kk)=length(CC.PixelIdxList{k});
                  % areas_in_pixels(kk)=length(CC.PixelIdxList{kk});
                idx =CC3.PixelIdxList{kk};
                V_onlySp(idx) =0;
            end
            
            for i=size(V_onlySp,3):-1:1
                 V_onlySp(:,:,i) = imfill(V_onlySp(:,:,i),'holes');
            end
            
            CC4 = bwconncomp(V_onlySp);
     
            numPixels2 = cellfun(@numel,CC4.PixelIdxList);
            for i = 1:z
                 imSp1 = V_onlySp(:,:,i);
                 %%figure(4); imshow(imSp1); title('only Spine');
                imwrite (imSp1, sprintf('%s%s%s%s',   writename2, Img_basal(ii).name, '_withSpineStack_onlySpine', imgType), 'WriteMode', 'append');
            end
            
            max_im1onlySp   = max(V_onlySp, [],3); 
            figure; imshow(max_im1onlySp); title(Img_basal(ii).name);
            
            rgbfibSpDilat3D(:,:,1) = max_im1onlySp;
            rgbfibSpDilat3D(:,:,2) = max_im1_all ;
            rgbfibSpDilat3D(:,:,3) = zeros(nImage, mImage);
            imwrite (rgbfibSpDilat3D, sprintf('%s%s%s%s%s',  writename2,'mip_', Img_basal(ii).name, '_rgbfiber_spines','.tif' ), 'tiff'); 
            clear   rgbfibSpDilat3D;

            %%figure, imshow(max_im1onlySp);  title('mip imfiber and spineTogether, imdliate3D1');
            imwrite (max_im1onlySp, sprintf('%s%s%s%s%s',  writename2,'mip_', Img_basal(ii).name, '_max_im1onlySp','.tif' ), 'tiff'); 
            
%               fileIDNum1= fopen(strcat(writename1,'_number of Terminals','.txt'), 'a+'); 
%               fileIDNum2= fopen(strcat(writename1, '_number of voxels','.txt'), 'a+'); 
%               fileIDNum3= fopen(strcat(writename1, '_averageSizeOfspine','.txt'), 'a+'); 
%               fileIDNum4= fopen(strcat(writename1, '_biggestSizeOfspine','.txt'), 'a+'); 
%                      
%                     
%               fprintf(fileIDNum1,'%s%s:  %10.8f\n', Img_basal(ii).name,'_number of individaul Terminals a', numOb);
%               fprintf(fileIDNum2,'%s%s:  %10.8f\n', Img_basal(ii).name,' _number of voxels', sum(numPixels));
%               fprintf(fileIDNum3,'%s%s:  %10.8f\n', Img_basal(ii).name,' _averageSizeOfspine', sum(numPixels)\numOb);
%               fprintf(fileIDNum4,'%s%s:  %10.8f\n', Img_basal(ii).name,' _biggestSizeOfspine', biggest);
%                  
         %%%     fprintf(fileIDNum5,'%s%s: %10.8f   %10.8f\n', Img_basal(ii).name,'_NumberofEpidermalFibers&Size', numOb, sum(numPixels2));
            % clear V2_3p;
            % clear Iskel3p;

%%
% raw_synapses = bwconncomp(Stack_thresh); % get all particles
% syn_props = regionprops(raw_synapses); % get region properties for all particles
% % % get plottable data from regionprops
% statistics_file = fopen(strcat(bw_path, sprintf('%d_statistics.txt', threshold)), 'w');

%%
%figure,
%imshow(max_im1onlySp); alpha(0.5); hold on;

threshold = 10;
testvol = V_delta(:,:,1:z)>threshold;
%testvol = V_onlySp;

   for i=size(testvol,3):-1:1
       testvol(:,:,i) = imfill(testvol(:,:,i),'holes');
   end

%skel1=padarray(testvol,[1 1 1]);
skel = Skeleton3D(testvol);
col=[0 .9 0];
hiso   = patch(isosurface(testvol,0),'FaceColor',col,'EdgeColor','none');
hiso2 = patch(isocaps(testvol,0),'FaceColor',col,'EdgeColor','none');
axis equal;axis off;
lighting phong;

isonormals(testvol,hiso);
alpha(0.5);
set(gca,'DataAspectRatio',[1 1 1])
camlight;
hold on;
w=size(skel,1);
l  =size(skel,2);
h =size(skel,3);
[x,y,z]=ind2sub([w,l,h],find(skel(:)));
plot3(y,x,z,'square','Markersize',1,'MarkerFaceColor','r','Color','r');    
%%skelLength = size(skel(:),1) 
skelLength2 =size(find(skel(:))>0,1)
set(gcf,'Color','white');
view(180,85)

%% skel2grap

w = size(skel,1);
l  = size(skel,2);
h = size(skel,3);

% convert skeleton to graph structure
[A,node,link] = Skel2Graph3D(skel,4);

% convert graph structure back to (cleaned) skeleton
skel2 = Graph2Skel3D(node,link,w,l,h);

% iteratively convert until there are no more 2-nodes left
[A2,node2,link2] = Skel2Graph3D(skel2,4);
% while(min(cellfun('length',{node2.conn}))<3)
%     skel2 = Graph2Skel3D(node2,link2,w,l,h);
%     [A2,node2,link2] = Skel2Graph3D(skel2,4);
% end;
% display result
hold on;

numberOfBranches=0;
numberOfjunctions =0;
for i=1:length(node2)
    x1 = node2(i).comx;
    y1 = node2(i).comy;
    z1 = node2(i).comz;
    for j=1:length(node2(i).links)    % draw all connections of each node
        if(node2(i).conn(j)<1)
            col='b'; % branches are blue
        else
            col='r'; % links are red
        end;
        
        % draw edges as lines using voxel positions
        for k=1:length(link2(node2(i).links(j)).point)-1            
            [x3,y3,z3]=ind2sub([w,l,h], link2(node2(i).links(j)).point(k));
            [x2,y2,z2]=ind2sub([w,l,h], link2(node2(i).links(j)).point(k+1));
            line([y3 y2],[x3 x2],[z3 z2],'Color',col,'LineWidth',3);
        end;
    end;
    
    % draw all nodes as yellow circles
    plot3(y1,x1,z1,'o','Markersize',6,  'MarkerFaceColor','y', 'Color','k');
    
end;
numberOfBranches = numel(node2)+2;
numberOfjunctions = numel(node2);

axis image;axis off;
set(gcf,'Color','white');
drawnow;
%%view(180,90)
%view(-17,46);
%%close all;
savefig(sprintf('%s%s%s',writename1, Img_basal(ii).name,'.fig'));
print('-dtiff','-r300',sprintf('%s%s%s',writename1, Img_basal(ii).name,'.tif'));

all_terminals = numOb+numberOfBranches;
density  =all_terminals \ skelLength2*100;

fprintf(fileIDNum6, '%s%s:,  %10.8f,  %10.8f,  %10.8f, %10.8f, %10.8f \n', Img_basal(ii).name, '_number of all Terminals a+b', numOb, numberOfBranches, all_terminals, skelLength2, density );
end   
