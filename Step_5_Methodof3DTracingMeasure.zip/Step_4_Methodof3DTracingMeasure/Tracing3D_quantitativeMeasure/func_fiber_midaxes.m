%
% {hongwei.zheng,kuner}@uni-heidelberg.de
%

function [skel1] =func_fiber_midaxes(Bm2, T1, T2,sigmay,se)

Bm1= medfilt2(Bm2);
Ie1 = imerode(Bm1, se); 
Iobr1 = imreconstruct(Ie1,Bm1 );
Iobrd1 = imdilate(Iobr1, se); 
%figure(1), imshow(Iobrd1); title('Iobrd')
Iobrcbr1 = imreconstruct(imcomplement(Iobrd1), imcomplement(Iobr1));
Iobrcbr1 = imcomplement(Iobrcbr1);
Bm1=Iobrcbr1 ;
% %figure(2), imshow(Iobrcbr1); title('Iobrdcbr1');
%%

skel1= findridges(255-Bm1,T1, T2,sigmay);
% figure, imshow(skel1),title('Out22');
% imwrite (skel1, sprintf('%s%s', i2s,'_skel' ), 'tiff');