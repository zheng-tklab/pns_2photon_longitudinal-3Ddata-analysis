%%% {hongwei.zheng,kuner}@uni-heidelberg.de
%%% TKuner LAB
% demo for running

%%
close all; clear all; clc;
pathm ='.\github_all\SingleDendrite\11-17-2015\11-17-2015_2.1-EtOH\binary\';
mice1 = '';
folder  = '';
result_folder ='compute_sp_4\';
func_counting_fiberData(pathm, mice1, folder, result_folder);


