%
% {hongwei.zheng,kuner}@uni-heidelberg.de
%

function RcolorT=findgetThining(Rcolor)

RcolorT = Rcolor ;
Raw = RcolorT ;
IterThinning=100
for Iter = 1:IterThinning
    OutBW1 = findCondition1( RcolorT, 0 ) ;
    OutBW2 = findCondition2( OutBW1, 0 ) ;
    RcolorT = OutBW2 ;
end