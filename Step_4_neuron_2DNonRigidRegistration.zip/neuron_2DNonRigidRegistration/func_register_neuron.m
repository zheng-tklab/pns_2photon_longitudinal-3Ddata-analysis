% Demo code for matching roughly based on the procedure
%
%%% {hongwei.zheng,kuner}@uni-heidelberg.de
%%% TKuner LAB
%

%function result = neuro_func_register_a(I1, I2,I1a, I2a, f1, f2)
function result = func_register_neuron(I1, I2, f1, f2)

% compute channels using oriented edge energy

addpath(genpath('./'));
addpath(genpath('../'));

fbr1 = compute_channels_oe_nms(I1);
fbr2 = compute_channels_oe_nms(I2);

% try it using only one channel
% fbr1 = sum(fbr1,3);
% fbr2 = sum(fbr2,3);

% Parameters for the geometric blur descriptor
%
% the units are pixels, these numbers can be changed, 
% keeping in mind that the normalization step inside 
% get_descriptors might need to be changed as well.
% rs are the radii for sample points
rs =      [0 4 8 16 32 50];

% nthetas are the number of samples at each radii
nthetas = [1 8 8 10 12 12];

% alpha is the rate of increase for blur
alpha = 0.5;

% beta is the base blur amount
beta = 1;

% Number of descriptors to extract per image
ndescriptors = 2000;

% repulsion radius for rejection sampling
rrep = 0.2;


% Actually extract Geometric Blur descriptors for each image
[descriptors1, pos1] = get_descriptors(fbr1,ndescriptors,rrep,alpha,beta,rs,nthetas);
[descriptors2, pos2] = get_descriptors(fbr2,ndescriptors,rrep,alpha,beta,rs,nthetas);


% % % % compute dissimilarity between features
% % % diss = -comp_features(descriptors1,descriptors2);
% % % sample_points = compute_sample_points(rs,nthetas);
% % % 
% % % % Interactively show the best match for points on the model,
% % % % click on a point in the left (model) image to see its similarity
% % % % to each point on the right image, with the best match marked with
% % % % a magenta star
if (size(I1,3)>1),  % convert the image to grayscale
  gI1 = mean(I1,3);
else 
    gI1= I1;
end
if (size(I2,3)>1),  % convert the image to grayscale
  gI2 = mean(I2,3);
else
    gI2= I2;
end

% % % vis_gb_match(gI1, pos1, gI2, pos2, descriptors1, descriptors2, diss, sample_points)
w = size(gI1,2);
h = size(gI1,1);
ff1(:,1) = pos1(:,1);
ff1(:,2) = pos1(:,2);
ff2(:,1) = pos2(:,1);
ff2(:,2) = pos2(:,2);
[corrlist]=func_ransac(I1, I2, ff1,ff2);

X(1,:) = corrlist(:,1)';
X(2,:) = corrlist(:,2)';
Y(1,:) = corrlist(:,3)';
Y(2,:) = corrlist(:,4)';

%%
figure,imshow(I1);title('I1'); hold on;
plot(X(1,:), X(2,:),'r.');  hold on;
plot(Y(1,:), Y(2,:),'b.');  hold on;
plot( [ Y(1,:)' X(1,:)']', [ Y(2,:)' X(2,:)']' ,'-g');
hold on;

% figure,imshow(I1a);title('I1'); hold on;
% plot(X(1,:), X(2,:),'r.');  hold on;
% plot(Y(1,:), Y(2,:),'b.');  hold on;
% plot( [ Y(1,:)' X(1,:)']', [ Y(2,:)' X(2,:)']' ,'-b');
% hold on;

figure,imshow(I1);title('I1'); hold on;
plot(corrlist(:,1)', corrlist(:,2)','r.');  hold on;
plot(corrlist(:,3)', corrlist(:,4)','b.');  hold on;
plot( [ corrlist(:,3) corrlist(:,1) ]', [ corrlist(:,4) corrlist(:,2) ]' ,'-r');
hold on;

figure,imshow(I2);title ('I2'); hold on;
plot(corrlist(:,1)', corrlist(:,2)','r.');  hold on;
plot(corrlist(:,3)', corrlist(:,4)','b.');  hold on;
plot( [ corrlist(:,3) corrlist(:,1) ]', [ corrlist(:,4) corrlist(:,2) ]' ,'-b');
hold on;
%%
%struct_3DRot_estimation(X,Y);
%%
% Set the options
opt.method='nonrigid';   % use rigid registration
opt.viz=1;             % show every iteration

% registering Y to X
Transform=reg_register(X',Y',opt);
% Now lets apply the found transformation to the image
% Create a dense grid of points
[x,y]=meshgrid(1:w,1:h); 
grid=[x(:) y(:)];

% Transform the grid according to the estimated transformation
T=reg_transform(grid, Transform);

% Interpolate the image
Tx=reshape(T(:,1),[w h]);
Ty=reshape(T(:,2),[w h]);
result=interp2(gI1,Tx,Ty);   %im  % evaluate image Y at the new gird (through interpolation)

% Show the result
figure,imshow(I1);      title('base image');
figure,imshow(I2);      title('unreg image');
figure,imshow(result); title('Result image');
imwrite(result,'register2_m807072nd_','tif');

figure, 
imshow(result); title('registered1 and I2'); hold on;
h = imshow(I2); title('result+I2');
set(h, 'AlphaData',0.6)

% figure, 
% imshow(result); title('result and I1'); hold on;
% h = imshow(I2a); title('result+I2a');
% set(h, 'AlphaData',0.6)
figure, 
imshow(result); title('result and I1'); hold on;
h = imshow(I1); title('result I1+I1');
set(h, 'AlphaData',0.6)

imwrite(result, sprintf('%s',f1,'_registered.tif')); 
%imwrite(result, sprintf('%s',f2,'_ref.tif')); 
  
figure; 
imshow(I2); title('I2 +result I1');
hold on
h = imshow(result); colormap cool;
set(h, 'AlphaData', 0.6)


