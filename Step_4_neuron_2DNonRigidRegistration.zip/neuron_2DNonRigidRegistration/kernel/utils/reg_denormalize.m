%  REG_DENORMALIZE Denormalizes template point set to its original scaling.
%   y=REG_DENORMALIZE(Y, normal) Denormalizes points in 
%   normalized point set Y to be scaled and shifted
%   back in the reference point set coordinate system.
%
%   Input
%   ------------------ 
%   Y          Normalized point set.
%
%   Output
%   ------------------ 
%   y          denormalized point set back in the reference point set system. 
%
%   normal     structure of scale and shift parameters
%
%   Examples
%   --------
%       x= [1 2; 3 4; 5 6;];
%       y=x;
%       [X, Y0, normal]=cpd_normalize(x,y);
%
%       x2=cpd_denormalize(X, normal);
%       norm(x-x2)
%
%%

function   Transform =reg_denormalize(Transform, normal, way)

switch lower(Transform.method)
    case {'rigid','affine'}
        Transform.s=Transform.s*(normal.xscale/normal.yscale);
        Transform.t=normal.xscale*Transform.t + normal.xd'-Transform.s*(Transform.R*normal.yd');
    case 'nonrigid'
        Transform.s=normal.xscale/normal.yscale;
        Transform.t=normal.xd'-Transform.s*normal.yd';
        Transform.W=Transform.W*normal.xscale;   
        Transform.beta=normal.yscale*Transform.beta;       
end







