% reg_MAKE compiles several reg functions as well as FGT-related functions,
 



function reg_make()

psave=pwd; p = mfilename('fullpath'); 
[pathstr, name, ext] = fileparts(p);

%%%%%%%%%%%%%%%%%%%% cpd_P %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp('Compiling reg_P-mex functions...');
disp('If this is the first time you use mex, it will ask you to choose a compiler.');
disp('Just choose the matlab default one (usually option #1).');
cd (pathstr); 
cd mex;

try
    mex reg_P.c;
    mex reg_Pappmex.c;
    mex reg_Pcorrespondence.c;
    disp('Compilation of reg_P mex functions is SUCCESSFUL.');
catch
   disp('Compilation of reg_P mex functions failed. Try to run mex -setup to adjust your compiler.');
    
end

%%%%%%%%%%%%%%%%%%%%%% FGT %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp('Compiling Fast Gauss Transform (FGT) related functions...');
disp('If the compilation fails, you can still perfectly run CPD only without FGT support.');
cd (pathstr); 
cd FGT;
disp('');

try
    mex fgt_model.c;
    mex fgt_predict.c;
    disp('Compilation of FGT mex functions is SUCCESSFUL.');
catch
   disp('Compilation of FGT mex functions failed. Try to run mex -setup to adjust your compiler.');
end


cd(psave);