% Demo code for matching roughly based on the procedure
%%% {hongwei.zheng,kuner}@uni-heidelberg.de
%%% TKuner LAB
%


close all
clear all
clc
addpath '../kernel/'

addpath(genpath('./'));
addpath(genpath('../'));
addpath(genpath('./../'));


%%
f1 = 'yfp_173_24012011_7d_small0499_2_inv_vio.tif';
f2 = 'yfp_173_31012011_14d_small0546_2_inv_green.tif';

I1 =   im2double(imresize(imread(f1),0.5));   %figure, imshow(I1); title('I1');
I2 =   im2double(imresize(imread(f2),0.5));   %figure, imshow(I2); title('I2');

base = I1;
unregistered = I2;

% cpselect(I1, I2);
load YFP_173_naive_7d_14d_small1800.mat


tform = cp2tform(input_points, base_points, 'projective');

registered1 = imtransform(unregistered,tform,...
                          'FillValues', 255,...
                          'XData', [1 size(base,2)],...
                          'YData', [1 size(base,1)]);
                      
figure; imshow(registered1); title('registered');
hold on
h = imshow(base, gray(256));
set(h, 'AlphaData', 0.6)

result = func_register_neuron(base, registered1, f1, f2);

