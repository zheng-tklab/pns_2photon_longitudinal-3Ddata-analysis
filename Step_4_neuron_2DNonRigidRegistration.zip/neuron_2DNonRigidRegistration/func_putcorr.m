%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% f1 and f2 are lists features (x,y) in the two images, img1 and img2
%%% {hongwei.zheng,kuner}@uni-heidelberg.de
%%% TKuner LAB
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
function [ putative_corr , num_corr ] = func_putcorr(img1,img2,f1,f2,blocksize)

nf1 = size(f1,1);
nf2 = size(f2,1);

% for i=1:nf1;
%  fprintf('points in image 1 %f %f\n',f1(i,:));
% end;
% 
% for i=1:nf2;
% fprintf('points in image 2  %f %f\n',f2(i,:));
% end;
% 

% for each point in f1 find the best match in its vicinity in the other image
w = size(img2,2);
h = size(img2,1);

for i=1:nf1;
    %fprintf('processing point %d in image 1',i);
    clear block;
    t1=f1(i,2) - blocksize/2;
    t2=f1(i,2) + blocksize/2;
    t3=f1(i,1) - blocksize/2;
    t4=f1(i,1) + blocksize/2;
    
    if (t1<=0) t1=1;
    end;
    if (t1>h) t1=h;
    end;
    
    if (t3<=0) t3=1;
    end;
    if (t3>w) t3=w;
    end;
    
    if (t2<=0) t2=1;
    end;
    if (t2>h) t2=h;
    end;
    
    if (t4<=0) t4=1;
    end;
    if (t4>w) t4=w;
    end;
  
    block = img1(t1:t2, t3:t4);
    clear list;
    % find a list of points in the other image which could be correspondences.
    list = findpoints(f1(i,:),f2 , w, h);
   
    if (list(1,:) == [ 0 0 0 ])
        % no matches were found 
        % so initialize to i th point in f2
        list = [f2(i,:) i];
    end;
    
    % find the best one amongst all based on ZMCC
    bestmatch1(i,:) = bestCorrPoint(f1(i,:),block,list,img2,blocksize);
end; % end of for i


%%  for each point in f2 find the best match in its vicinity in the other image
w = size(img1,2);
h = size(img1,1);
for i=1:nf2;
    %fprintf('processing point %d in image 2',i);
    t1=f2(i,2) - blocksize/2;
    t2=f2(i,2) + blocksize/2;
    t3=f2(i,1) - blocksize/2;
    t4=f2(i,1) + blocksize/2;
        
    if (t1<=0) t1=1;
    end;
    if (t1>h) t1=h;
    end;
    
    if (t3<=0) t3=1;
    end;
    if (t3>w) t3=w;
    end;
    
    if (t2<=0) t2=1;
    end;
    if (t2>h) t2=h;
    end;
    
    if (t4<=0) t4=1;
    end;
    if (t4>w) t4=w;
    end;
    %block = img2(f2(i,2) - blocksize/2 : f2(i,2) + blocksize/2 , f2(i,1) - blocksize/2 : f2(i,1) + blocksize/2 );
    block =img2(t1:t2 , t3:t4);
    clear list;
    % find a list of points in the other image which could be correspondences.
    list = findpoints(f2(i,:),f1 , w, h);

    if (list(1,:) == [0 0 0])
        % no matches were found 
        % so initialize to i th point in f2
        list = [f2(i,:) i];
    end;
    
    % find the best one amongst all based on ZMCC
    bestmatch2(i,:) = bestCorrPoint(f2(i,:),block,list,img1,blocksize);
end;

% verify that the matches correspond to each other in the 2 lists
% bestmatch1 and bestmatch2

num_corr = 1;
for i=1:size(bestmatch1,1);
    if (bestmatch2( bestmatch1(i,3) , 3 ) == i )
        %fprintf('point f1(%d) matches point f2(%d)\n',i,bestmatch1(i,3));
        putative_corr(num_corr,:) = [ f1(i,1) f1(i,2) bestmatch1(i,1) bestmatch1(i,2) ];
        num_corr = num_corr + 1;
    end;
end;
num_corr = num_corr - 1;
fprintf('total no of matches : %d\n',num_corr);

%-----------------------------------------------------------------------------%
% find a subset of 'candidates' which could be possible matches for 'point'

function l = findpoints(point, candidates,w,h)

DISP_RANGE = 20;

xmin = point(1,1) - w/DISP_RANGE;
xmax = point(1,1) + w/DISP_RANGE;
ymin = point(1,2) - h/DISP_RANGE;
ymax = point(1,2) + h/DISP_RANGE;

count=1;
sz = size(candidates,1);
for i=1:sz
    if ( (candidates(i,1) > xmin ) & ( candidates(i,1) < xmax ) & (  candidates(i,2) > ymin ) & ( candidates(i,2) < ymax ) )
        % fprintf('point %d is a possible match\n',i);
        l(count,:) = [ candidates(i,:) i ];
        % l(count,3) = i;
        count = count + 1;
     end;
 end;
 
 if (count==1)
     l(1,:)=[0 0 0];
 end;

%-----------------------------------------------------------------------------%

% find out which of the candidates is the best match for 'point'
% block is the image block centered at point.
function bm = bestCorrPoint(point,block,candidates,image,blocksize)

h=size (image,1);
w=size(image,2);

sz = size(candidates,1);
for k=1:sz
    % debug : display value of block and block1
   
    t1=candidates(k,1) - blocksize/2;
    t2=candidates(k,1) + blocksize/2;
    t3=candidates(k,2) - blocksize/2;
    t4=candidates(k,2) + blocksize/2;
    
    if (t1<=0) t1=1;
    end;
    if (t1>w) t1=w;
    end;
    
    if (t3<=0) t3=1;
    end;
    if (t3>h) t3=h;
    end;
    
    if (t2<=0) t2=1;
    end;
    if (t2>w) t2=w;
    end;
    
    if (t4<=0) t4=1;
    end;
    if (t4>h) t4=h;
    end;
    
    %block1 = image(candidates(k,2) - blocksize/2 : candidates(k,2) + blocksize/2 , ...
    %               candidates(k,1) - blocksize/2 : candidates(k,1) + blocksize/2 );
    
    block1 = image(t3:t4, t1:t2);
    score(k) = func_normcorr(size(block),size(block1),double(block(:)'),double(block1(:)'));
end;

max = -999999;
for k=1:sz;
    if (score(k) > max ) 
        max = score(k);
        max_ind = k;
    end;
end;
bm = candidates(max_ind,:);
    
  