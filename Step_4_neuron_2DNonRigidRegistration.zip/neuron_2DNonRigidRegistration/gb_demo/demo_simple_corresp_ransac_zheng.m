 % Demo code for matching roughly based on the procedure
% described in:
%
% "Shape Matching and Object Recognition using Low Distortion Correspondence"
% A. C. Berg, T. L. Berg, J. Malik
% CVPR 2005
%
% code Copyright 2005 Alex Berg
%
% questions -> Alex Berg aberg@cs.berkeley.edu

%%% {hongwei.zheng,kuner}@uni-heidelberg.de
%%% TKuner LAB
%


close all
clear all
clc

addpath(genpath('..\'));
addpath(genpath('.\'));


% Load two images
% I1 = im2double(imread('data/1.jpg'));
% I2 = im2double(imread('data/2.jpg'));

% I1 = im2double(imread('/media/LaCie/MIP/m3_sni/sm32806c1357_noHull500_2.tif'));
% I2 = im2double(imread('/media/LaCie/MIP/m3_sni/sm30106c1357_noHull395_3.tif'));

% I1 = imresize(im2double(imread('yfp_173_basal_small0568_2_inv_red.tif')),0.3);
% I2 = imresize(im2double(imread('yfp_173_3d_small0547_2_inv_b.tif')),0.3);

I1 = imresize(im2double(imread('yfp_173_24012011_7d_small0499_2_inv_vio.tif')),0.3);
I2 = imresize(im2double(imread('yfp_173_02022011_small0401_2_inv_yellow.tif')),0.3);


if (size(I1,3)>1),  % convert the image to grayscale
  I1 = mean(I1,3);
end


if (size(I2,3)>1),  % convert the image to grayscale
  I2 = mean(I2,3);
end

% compute channels using oriented edge energy
fbr1 = compute_channels_oe_nms(I1);
fbr2 = compute_channels_oe_nms(I2);

% try it using only one channel
% fbr1 = sum(fbr1,3);
% fbr2 = sum(fbr2,3);

% Parameters for the geometric blur descriptor
%
% the units are pixels, these numbers can be changed, 
% keeping in mind that the normalization step inside 
% get_descriptors might need to be changed as well.
%

% rs are the radii for sample points
rs =      [0 4 8 16 32 50];

% nthetas are the number of samples at each radii
nthetas = [1 8 8 10 12 12];

% alpha is the rate of increase for blur
alpha = 0.5;

% beta is the base blur amount
beta = 1;

% Number of descriptors to extract per image
ndescriptors = 500;

% repulsion radius for rejection sampling
rrep = 5;


% Actually extract Geometric Blur descriptors for each image
[descriptors1, pos1] = get_descriptors(fbr1,ndescriptors,rrep,alpha,beta,rs,nthetas);
[descriptors2, pos2] = get_descriptors(fbr2,ndescriptors,rrep,alpha,beta,rs,nthetas);


% compute dissimilarity between features
diss = -comp_features(descriptors1,descriptors2);
sample_points = compute_sample_points(rs,nthetas);

% Interactively show the best match for points on the model,
% click on a point in the left (model) image to see its similarity
% to each point on the right image, with the best match marked with
% a magenta star

vis_gb_match(I1, pos1, I2, pos2, descriptors1, descriptors2, diss, sample_points)

%%
btn = 1;
% X=X;
% Y = Transform.Y;
func_GIH_geo(I1, I2, pos1, pos2)


% %%
w = size(I1,2);
h = size(I1,1);
ff1(:,1) = pos1(:,1);
ff1(:,2) = pos1(:,2);
ff2(:,1) = pos2(:,1);
ff2(:,2) = pos2(:,2);
[corrlist]=func_ransac(I1, I2, ff1,ff2, w,h);

% 
% 
% %%
num1 = size(corrlist(:,3));
                      
    aa(1,:) = corrlist(:,3);     
    aa(2,:) = corrlist(:,1);


    bb(1,:) = corrlist(:,4)';
    bb(2,:) = corrlist(:,2)';

X= aa';
Y= bb';

