%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% computes the normalized cross correlation of 2 windows 
%%% {hongwei.zheng,kuner}@uni-heidelberg.de
%%% TKuner LAB
%


function v = func_normcorr(s1,s2,v1,v2)

clear v1bar
clear v2bar
v1bar = mean(v1);
v2bar = mean(v2);
if ( (norm(v1-v1bar) ~= 0 ) & ( norm(v2-v2bar)~=0) )
    if (s1==s2)
         v = dot( (v1 - v1bar ), ( v2 - v2bar ) ) / ( norm( v1 - v1bar ) * norm( v2 -v2bar ) );
    else
         v = 1000;
    end;
else 
    v=1000;
end;
return;

