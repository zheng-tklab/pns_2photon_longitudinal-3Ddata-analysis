
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% 4 correspondence are given, then an exact solution for the matrix is
%% possible.This is a minimum solution.If more than 4 correspondences are
%% given, then these correspondences may not be fully compatiable with any
%% projective transformation. And will determine the "best" transformation
%% given data.This will be done by by finding the transformation H that
%% minimizes some cost function, minimize geometric or statistical image
%% distance.
%%
%%% {hongwei.zheng,kuner}@uni-heidelberg.de
%%% TKuner LAB
%
%% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% globals
% img1, img2 : images.
% ncorr      : number of correspondences. 
% corrlist   : 4 tuples [ xa ya xb yb ]

% clear all



% fprintf('Automatic Computation of Fundamental Matrix starting ...\n');
% % Load Images.
% fprintf('Loading Images ...\n');
% 
% fileName_1 = '001.jpg';
% fileName_2 = '002.jpg';

function [corrlist]=func_ransac(I1, I2, ff1, ff2, w,h)

t_THRESHOLD = 1.5;
BLOCKSIZE   = 60;
I1;
I2;



fprintf('Detecting Corners in Image 1 ...\n');
% call corner_detector.m function
%  ff1 = corner_detector(img1,1000);   
num1 = size(ff1,1);
fprintf('Found %d corners\n',num1);

fprintf('Detecting Corners in Image 2 ...\n');
% ff2 = corner_detector(img2,1000);
num2 = size(ff2,1);
fprintf('Found %d corners\n',num2);

%storing 2 lists of feature corners
for i=1:num1                        
    point1(i,1) = ff1(i,2);      
    point1(i,2) = ff1(i,1); 
end;

for i=1:num2
    point2(i,1) = ff2(i,2);
    point2(i,2) = ff2(i,1);
end;

% computing putative correspondences.

fprintf('Computing Putative Correspondences.....\n');
% get putativeCorrespondence.m function
[corrlist , ncorr ] = func_putcorr(I1,I2,point1,point2,BLOCKSIZE);

fprintf('Displaying the line corresponding to the Putative Correspondences in both images.....\n');
         
% show image 1 and 2        
figure,imshow(I1);xlabel('putative matching'),title('I1');hold on;axis ij;hold on;
plot( [ corrlist(:,3) corrlist(:,1) ]', [ corrlist(:,4) corrlist(:,2) ]' ,'-r.');

figure,imshow(I2);xlabel('putative matching'),title('I2');hold on;axis ij;hold on;
plot( [ corrlist(:,3) corrlist(:,1) ]',  [ corrlist(:,4) corrlist(:,2) ]' ,'-b.');

figure,imshow(I1);title('I1'); hold on;
plot(corrlist(:,1)', corrlist(:,2)','r.');  hold on;
plot(corrlist(:,3)', corrlist(:,4)','b.');  hold on;
plot( [ corrlist(:,3) corrlist(:,1) ]', [ corrlist(:,4) corrlist(:,2) ]' ,'-g');
hold on;

figure,imshow(I2);title ('I2'); hold on;
plot(corrlist(:,1)', corrlist(:,2)','r.');  hold on;
plot(corrlist(:,3)', corrlist(:,4)','b.');  hold on;
plot( [ corrlist(:,3) corrlist(:,1) ]', [ corrlist(:,4) corrlist(:,2) ]' ,'-b');
hold on;


% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %% RANSAC: implemented here
% %% GANSAC: (proposd by Volker Rodehorst,2003)can be implemented later which 
% %% is quicker than RANSAC in principle.
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% % globals
% % img1, img2 : images.
% % ncorr      : number of correspondences. 
% % corrlist   : 4 tuples [ xa ya xb yb ]
% 
% for s=1:ncorr
%     a(s,1) = corrlist(s,1);
%     a(s,2) = corrlist(s,2); 
%     a(s,3) = 1;
%     
%     b(s,1) = corrlist(s,3);
%     b(s,2) = corrlist(s,4);
%     b(s,3) = 1;
% end;
% 
% fprintf('Running RANSAC to filter outliers ....\n');
% 
% if (ncorr <= 7 ) 
%     error('The number of correspondences need to be greater than 7');
% end;
% 
% fprintf('Estimating the number of samples N ...\n');
% 
% N = estimateN;
% 
% fprintf('For %d random sample Compute Consistent Set and the support ..\n',N);
% 
% for r =1:N
%     
%     % compute a random sample of 7 points.  
%     
%     ran_tuple(r,:) = selectRandom(ncorr,7);
%     
%     %     fprintf('random 7 tuple\n');
%     %     for q=1:7
%     %         fprintf('%d  ',ran_tuple(r,q));
%     %     end;
%     
%     % compute the F matrix from these 7 points and the 7 point algorithm
%     
%     fprintf( '\nCompute F using 7 point linear algorithm for sample %d\n',r);
%     3
%     clear aa
%     clear bb
%     for k= 1:7
%         i = ran_tuple(r,k);
%         aa(k,:) = [ corrlist(i,1) corrlist(i,2) 1];
%         bb(k,:) = [ corrlist(i,3) corrlist(i,4) 1];
%     end;
% % call linear7points.m function
%     [Fx,n] = linear7point( aa, bb ); 
%     
%     % case 1 : 1 solution.
%     if (n==1) 
%         FM(r,:,:) = Fx(1,:,:);
%     end;
% 
%     % case 2 : 3 solutions.
%     if (n==3)
%        for u=1:3 
%            n(u)=0;
%            for s=1:ncorr
%                 %temp(:,:) = Fx(u,:,:);
%                 %temp = temp';
%                 %d1(u,s) = sampsonerr(temp(:), [ corrlist(s,1) corrlist(s,2) 1] , [ corrlist(s,3) corrlist(s,4) 1] );
%                 temp(:,:)=Fx(u,:,:);
%                 d1(u,s) =sampsonerr(temp, [ corrlist(s,1) corrlist(s,2) 1] , [ corrlist(s,3) corrlist(s,4) 1] );
%                 if (d1(u,s) < t_THRESHOLD)
%                      n(u) = n(u) + 1;
%                 end;
%            end;
%        end;
%        %fprintf('the number of inliers for the 3 Fs are %d %d %d\n',n);
%        [nmax,nmax_id] = max(n);
%        FM(r,:,:) = Fx(nmax_id,:,:);
%     end;
%      
%     % compute the distance threshold d_perp for all correspondences for 
%     % value of F.
%     % computing the number of inliers.
%     
%     num_inlier(r) = 0;
%     for s=1:ncorr
% %         temp(:,:) = FM(r,:,:);
% %         temp = temp';
% %         d_perp(s) = sampsonerr(temp(:), [ corrlist(s,1) corrlist(s,2) 1] , [ corrlist(s,3) corrlist(s,4) 1] );
%           temp(:,:) = FM(r,:,:);
%           d_perp(s) = sampsonerr( temp, [ corrlist(s,1) corrlist(s,2) 1] , [ corrlist(s,3) corrlist(s,4) 1] );
%         %fprintf('d_perp(%d) = %8f\n',s,d_perp(s));    
%         
%         if (d_perp(s) < t_THRESHOLD)
%             num_inlier(r) = num_inlier(r) + 1;
%         end;
%     end;
%     % check standard derivation error
%     std_d_perp(r) = std(d_perp);
% end;
% 
% % find the F with the largest no. of inliers.
% 
% [max_inliers,mi] = max(num_inlier);
% 
% [ mi, mi_count ] = returnallinstances(num_inlier,N,max_inliers);
% 
% for x=1:mi_count
%     temp_array(x) = std_d_perp( mi(x) );
% end;
% 
% temp_array';
% 
% % find the F corresponding to the minimum standard deviation of inliers.
% [ chosen_one, ci ] = min(temp_array);
% mi(ci);
% 
% fprintf('The maximum no of inliers was %d\n\n',max_inliers);
% fprintf('The Fundamental Matrix obtained through RANSAC is\n');
%     for d=1:3
%         fprintf('%f %f %f\n',FM(mi(ci),d,:));
%     end;
%     
% % ==============================================================   
% clear a;
% clear b;
% num_in = 1;
% for s=1:ncorr
% %    temp(:,:) = FM(mi(ci),:,:);
% %    temp = temp';
% %    d_perp(s) = sampsonerr(temp(:), [ corrlist(s,1) corrlist(s,2) 1] , [ corrlist(s,3) corrlist(s,4) 1 ] ); 
%     temp(:,:) = FM(mi(ci),:,:);
%     d_perp(s) = sampsonerr(temp, [ corrlist(s,1) corrlist(s,2) 1] , [ corrlist(s,3) corrlist(s,4) 1 ] );
%    if (d_perp(s) < t_THRESHOLD)
%         temp1 = [corrlist(s,1) corrlist(s,2) 1]';
%         a(num_in,:)= temp1';
%         temp1 = [corrlist(s,3) corrlist(s,4) 1]';
%         b(num_in,:) = temp1';
%         num_in = num_in + 1;
%     end;
% end;
% 
% FundaM(:,:) = FM(mi(ci),:,:)
% num_in = num_in - 1;
% 
% fprintf('There are %d inliers\n',num_in);
% %fprintf('points in image 1\n');
% %fprintf('points in image 2\n');
% 
% % Re-estimate the Fundamental Matrix from all inliers using non linear minimisation method.
% FinalF = solveF(I1,I2,w,h,FundaM,num_in,a,b)
% fprintf('The Fundamental Matrix obtained through First Iteration of Non Linear Minimization of Sampson Err is\n');
%     for d=1:3
%         fprintf('%f %f %f\n',FinalF(d,:));
%     end;
% 
