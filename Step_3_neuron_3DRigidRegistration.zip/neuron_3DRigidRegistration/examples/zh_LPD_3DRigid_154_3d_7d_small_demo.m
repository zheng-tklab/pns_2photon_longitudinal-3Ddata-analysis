% Example 3D points clouds extracted from image 3D stacks for registration parameter estimation.
% Full options intialization.
% Make use of Fast Gauss transform. Try it with FGT (opt.fgt=1) and without
%%% {hongwei.zheng,kuner}@uni-heidelberg.de
%%% TKuner LAB
%

clear all; close all; clc;
addpath '../kernel/'

%% load xyz datasets

filename1 ='./neuro_data_txt/154_11_06_19-5th-3daysaftershame_onlypoint.txt';
fid = fopen(filename1,'r');


if( fid==-1 )
    error('Can''t open the file.');
    return;
end 


nvert = 28605; %7 %268495 %495

str = fgets(fid);   % -1 if eof
% if ~strcmp(str(1:4), 'shp')

[A,cnt] = fscanf(fid,'%f %f %f %f %f %f %f', [7*nvert]);


for i = 1:20:nvert
Ax(i) = A(1+7*(i-1));
Ay(i) = A(2+7*(i-1));
Az(i) = A(3+7*(i-1));

end
 X=[Ax; Ay; Az]';
figure,
  plot3( Ax,Ay, Az, 'r.'); title('plot3 inside');



%%
filename1 ='./neuro_data_txt/154_11_06_19-5th-7daysaftershame_onlypoint.txt';
fid = fopen(filename1,'r');

if( fid==-1 )
    error('Can''t open the file.');
    return;
end 


nvert =28605; %38547;%268495 %495

str = fgets(fid);   % -1 if eof
% if ~strcmp(str(1:4), 'shp')

%     error('The file is not a valid shp one.');    
% end

% fgets read the head file
% str = fgets(fid)
% [a,str] = strtok(str); nvert = str2num(a)
% [a,str] = strtok(str); nface = str2num(a);

[A,cnt] = fscanf(fid,'%f %f %f %f %f %f %f', [7*nvert]);

% zlevel =840:70:19810;

for i = 1:20:nvert
Ax(i) = A(1+7*(i-1));
Ay(i) = A(2+7*(i-1));
Az(i) = A(3+7*(i-1));

end
Y=[Ax; Ay; Az]';
figure,
plot3( Ax,Ay, Az, 'b.'); title('plot3 inside');

  
%Y=X;

% add a random rigid transformation
R=reg_R(rand(1),rand(1),rand(1));
X=rand(1)*X*R';


% Set the options
opt.method='rigid';  % use rigid registration, nonrigid_lowrank
opt.viz=1;                % show every iteration
opt.outliers=0.5;      % use 0.6 noise weight

opt.normalize=1;    % normalize to unit variance and zero mean before registering (default)
opt.scale=1;           % estimate global scaling too (default)
opt.rot=1;              % estimate strictly rotational matrix (default)
opt.corresp=1;       % do not compute the correspondence vector at the end of registration (default). Can be quite slow for large data sets.

opt.max_it=100;     % max number of iterations
opt.tol=1e-11;       % tolerance
opt.fgt=1;          % [0,1,2] if > 0, then use FGT. case 1: FGT with fixing sigma after it gets too small (faster, but the result can be rough)
                    %  case 2: FGT, followed by truncated Gaussian approximation (can be quite slow after switching to the truncated kernels, but more accurate than case 1)

 

% registering Y to X
[rigidT,C]=reg_register(X,Y,opt);

figure,reg_plot_iter(X, Y); title('Before'); grid on
figure,reg_plot_iter(X, rigidT.Y,C);  title('After rigid-registering Y to X'); grid on

