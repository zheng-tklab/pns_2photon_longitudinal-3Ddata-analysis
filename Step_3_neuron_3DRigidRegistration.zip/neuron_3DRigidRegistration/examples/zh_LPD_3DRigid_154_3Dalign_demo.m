% Rigid 3D point-set registration and parameter estiamtion. 
% Full options intialization.
% if some options are not set, the defaults are used. 
% Make use of Fast Gauss transform. Try it with FGT (opt.fgt=1) and without
% FGT (opt.fgt=0).

%%% {hongwei.zheng,kuner}@uni-heidelberg.de
%%% TKuner LAB
%

%% uni-heidelberg.de


clear all; close all; clc;

addpath '../kernel/'
addpath (genpath('./'))

%% load file

%filename1 ='./neuro_data_txt/extract_YFP_183_sni_29042011_basal_3rd_xyz.txt';
filename1 ='./neuro_data_txt/154_11_06_19-5th-3daysaftershame_xyz.txt';
fid = fopen(filename1,'r');
formatSpec = '%f %f %f';
sizeA = [3 Inf];

if( fid==-1 )
    error('Can''t open the file.');
    return;
end 

[A,cnt] = fscanf(fid, formatSpec, sizeA);
nvert =size(A,2);

for i = 1:1000:nvert
    Ax1(i) = A(1+3*(i-1));
    Ay1(i) = A(2+3*(i-1));
    Az1(i) = A(3+3*(i-1));
end
Ax =Ax1(Ax1~=0);
Ay =Ay1(Ay1~=0);
Az =Az1(Az1~=0);

X=[Ax; Ay; Az]';

figure,
plot3( Ax,Ay, Az, 'r.'); title('plot3 inside');grid on;

%%
%filename2 ='./neuro_data_txt/extract_YFP_183_sni_0627_56days_3rd_xyz.txt';
filename2 ='./neuro_data_txt/154_11_06_19-5th-7daysaftershame_xyz.txt';

fid2 = fopen(filename2,'r');
formatSpec = '%f %f %f';
sizeB2= [3 Inf];

% A = fscanf(fileID,formatSpec,sizeA)

if( fid2==-1 )
    error('Can''t open the file.');
    return;
end 

nvert2 =Inf;
[B2,cnt2] = fscanf(fid2, formatSpec, sizeB2);
nvert2 =size(B2,2);
for ii = 1:1000:nvert2
    Bx2(ii) = B2(1+3*(ii-1));
    By2(ii) = B2(2+3*(ii-1));
    Bz2(ii) = B2(3+3*(ii-1));
end

Bx =Bx2(Bx2~=0);
By =By2(By2~=0);
Bz =Bz2(Bz2~=0);
Y=[Bx; By; Bz]';

figure,
plot3( Bx,By, Bz, 'b.'); title('plot3 inside');grid on;

  
% add a random rigid transformation
% R=reg_R(rand(1),rand(1),rand(1));
% X=rand(1)*X*R';


%% % Set the options
opt.method='rigid';    % use rigid registration, nonrigid_lowrank
opt.viz=0;             % show every iteration
opt.outliers=0;       % use 0.6 noise weight
opt.lambda=3;  
opt.beta=2; 

opt.normalize=1;    % normalize to unit variance and zero mean before registering (default)
opt.scale=1;           % estimate global scaling too (default)
opt.rot=1;              % estimate strictly rotational matrix (default)
opt.corresp=1;       % do not compute the correspondence vector at the end of registration (default). Can be quite slow for large data sets.

opt.fgt=0; 

opt.max_it=100;     % max number of iterations
opt.tol=1e-11;       % tolerance
% opt.fgt=1;          % [0,1,2] if > 0, then use FGT. case 1: FGT with fixing sigma after it gets too small (faster, but the result can be rough)
                    %  case 2: FGT, followed by truncated Gaussian approximation (can be quite slow after switching to the truncated kernels, but more accurate than case 1)

 
%%
% registering Y to X, RigidT has all parameters for 3D image stacks
% alignments.
[rigidT,C]=reg_register(X,Y,opt);

figure,reg_plot_iter(X, Y, C); title('Before'); grid on
figure,reg_plot_iter(X, rigidT.Y,C);  title('After rigid-registering Y to X'); grid on



