%   REG_PLOT_iter(X, Y, C); plots 2/3 data sets. Works only for 2D and 3D data sets.
%
%   Input
%   ------------------ 
%   X           Reference point set matrix NxD;
%   Y           Current postions of GMM centroids;
%   C           (optional) The correspondence vector, such that Y corresponds to X(C,:) 
%
%%

function reg_plot_iter(X, Y, C)

if nargin<2, error('reg_plot.m error! Not enough input parameters.'); end
[m, d]=size(Y);

if d>3, error('reg_plot.m error! Supported dimension for visualizations are only 2D and 3D.'); end
if d<2, error('reg_plot.m error! Supported dimension for visualizations are only 2D and 3D.'); end

%%%%% for 2D case
if d==2
   plot(X(:,1), X(:,2),'r*', Y(:,1), Y(:,2),'bo'); %axis off; axis([-1.5 2 -1.5 2]);
else
% for 3D case
   plot3(X(:,1),X(:,2),X(:,3),'r.', Y(:,1),Y(:,2),Y(:,3),'bo');  title('X data (red). Y GMM centroids (blue)');set(gca,'CameraPosition',[15 -50 8]);
end

% % % %%
%     hold on;
%     if d==2,
%         for i=1:m,
%          %   plot([X(C(i),1) Y(i,1)],[X(C(i),2) Y(i,2)], 'g-');
%             plot([X(:,1),X(:,2)]', [Y(:,1),Y(:,2) ]', 'g-');
%         end
%     else
%         for i=1:m,
%            plot3([X(C(i),1) Y(i,1)], [X(C(i),2) Y(i,2)],[X(C(i),3) Y(i,3)], 'g-');
%          %   plot3([X(:,1),X(:,2),X(:,3)], [Y(:,1),Y(:,2),Y(:,3) ], 'g-');
%         end
%     end
%     hold on;


% plot correspondences
if nargin>2
    hold on;
    if d==2
        for i=1:m
            plot([X(C(i),1) Y(i,1)],[X(C(i),2) Y(i,2)], 'g-');
        end
    else
        for i=1:m
            plot3([X(C(i),1) Y(i,1)],[X(C(i),2) Y(i,2)],[X(C(i),3) Y(i,3)], 'g-');
        end
    end
    hold on;
end

drawnow;
    
% % %%
% % % % % plot correspondences
% % if nargin>2,
% %     hold on;
% %     if d==2,
% %         for i=1:m,
% %             plot([X(C(i),1) Y(i,1)], [X(C(i),2) Y(i,2)], 'g-');
% %         end
% %     else
% %         for i=1:m,
% %         % plot([X(C(i),1) Y(i,1)], [X(C(i),2) Y(i,2)], 'g-');
% %           plot3([X(C(i),1),X(C(i),2),X(C(i),3)], [Y((i),1),Y((i),2),Y((i),3)],'g-'); 
% %         end
% %     end
% %    % hold off;
% % end
% % 
% % drawnow;
