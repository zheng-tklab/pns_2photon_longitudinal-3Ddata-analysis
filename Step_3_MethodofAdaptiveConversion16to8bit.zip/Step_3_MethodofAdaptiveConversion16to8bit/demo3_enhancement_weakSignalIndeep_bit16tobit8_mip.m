%%hongwei.zheng@uni-heidelberg.de
%%


imbit16 = imread('MAX_Mice_631_TauGFP_naive_3rd.tif');
figure, imshow(imbit16); title('original');

AInv16 = imcomplement(imbit16);
imshow(AInv16);

BInv = imreducehaze(AInv16,'ContrastEnhancement','none');
imshow(BInv);

B = imcomplement(BInv16);
montage({imbit16,B});

BInv = imreducehaze(AInv16, 'Method','approx','ContrastEnhancement','boost');
BImp = imcomplement(BInv);
figure, montage({imbit16, BImp});



