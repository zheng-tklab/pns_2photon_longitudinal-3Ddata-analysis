%% {hongwei.zheng,kuner}@uni-heidelberg.de
%% Kuner LAB

%%
clear all; close all; clc;
func_mkdir_2channels;
path1='/data/Mice_636_TauGFP_naive/3rd/';
path2 ='130611_Mice636_3rdtibial_Naive_20-19-52/';
name1 ='Mice636_3rdtibial_Naive_20-19-52_PMT';
path = strcat(path1, path2);
addpath(path);
dataSeq = dir([path '*_C00_*']);
numList =1:1:length(dataSeq)-1;
dataSeq_name1 = strcat(path, name1, ' - xyz-Table[0] - xyz-Table[0]_C00_xyz-Table Z');
dataSeq_name3 = strcat(path, name1, ' - xyz-Table[0] - xyz-Table[1]_C01_xyz-Table Z');  
writeSeq_name = strcat(path1,'c1c2/c1c2_');
imageTypeNumber=1;
deltaX=102; %% measured by sift
deltaY=-10;
b_func2imgRG16bitDeltaX(numList, dataSeq_name1, dataSeq_name3, writeSeq_name,deltaX, deltaY,imageTypeNumber);

dataSeq_name1 = strcat(path, name1, ' - xyz-Table[1] - xyz-Table[0]_C02_xyz-Table Z');
dataSeq_name3 = strcat(path, name1, ' - xyz-Table[1] - xyz-Table[1]_C03_xyz-Table Z');  
writeSeq_name = strcat(path1,'c3c4/c3c4_');
imageTypeNumber=1;
%%[deltaX, deltaY] = func_load3Dstack_matching (numList, dataSeq_name1, dataSeq_name3,imageTypeNumber);
deltaX=108;
deltaY=-8;
b_func2imgRG16bitDeltaX(numList, dataSeq_name1, dataSeq_name3, writeSeq_name,deltaX, deltaY,imageTypeNumber);

dataSeq_name1 = strcat(path1, 'c1c2/');           
dataSeq_name3 = strcat(path1, 'c3c4/');                               
writeSeq_name = strcat(path1, 'c1234/c1234_');
wrt1800       = strcat(path1, '1800/c1234_');   
wrt18008b     = strcat(path1, '1800/bit8c_');
wrt450        = strcat(path1, '450/tc1234_');
%%[deltaX, deltaY] = func_load3Dstack_matching (numList, dataSeq_name1, dataSeq_name3,imageTypeNumber);
deltaX=102;
deltaY=-4;
b_func4RGDeltaX(numList, dataSeq_name1, dataSeq_name3, writeSeq_name, wrt1800,wrt18008b,wrt450,deltaX,deltaY)
clear all; close all;
