%GOPEN   Alias for OPENING.

function out = gopen(varargin)
out = opening(varargin{:});
