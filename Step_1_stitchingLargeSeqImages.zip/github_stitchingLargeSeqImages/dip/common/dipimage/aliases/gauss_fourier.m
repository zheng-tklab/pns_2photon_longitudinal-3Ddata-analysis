%GAUSS_FOURIER   Alias for DERIVATIVE

function image_out = gauss_fourier(varargin)
image_out = derivative(varargin{:});
