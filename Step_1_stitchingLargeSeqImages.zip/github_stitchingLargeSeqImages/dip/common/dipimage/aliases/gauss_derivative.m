%GAUSS_DERIVATIVE   Alias for DERIVATIVE

function image_out = gauss_derivative(varargin)
image_out = derivative(varargin{:});
