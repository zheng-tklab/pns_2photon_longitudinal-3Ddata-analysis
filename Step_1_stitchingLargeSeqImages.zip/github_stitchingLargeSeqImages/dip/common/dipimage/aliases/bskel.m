%BSKEL   Alias for BSKELETON.

function out = bskel(varargin)
out = bskeleton(varargin{:});
