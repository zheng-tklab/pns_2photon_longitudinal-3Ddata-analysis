%
% Labeled image color map.
% m = 14 for the minimal set.
% The first item is [0,0,0] for background.
%
function g = label_colormap(m)
if nargin<1
   m = 256; % length of color map
end
%h = ((0:n-1)/n)';  % this generates three colors that are crap
h = [       0
       0.0625
        0.125
       0.1875
         0.25 %0.3125
        0.375
       0.4375
          0.5
       0.5625 %0.625
       0.6875
         0.75
       0.8125
        0.875 ]; %0.9375
n = length(h);
col = hsv2rgb([h,ones(n,2)]);
g = [0,0,0;col(mod((2:m)-2,n)+1,:)];
