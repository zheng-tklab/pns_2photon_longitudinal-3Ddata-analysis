%UMINUS   Overloaded operator for -a.

% (C) Copyright 1999-2009               Pattern Recognition Group
%     All rights reserved               Faculty of Applied Physics
%                                       Delft University of Technology
%                                       Lorentzweg 1
%                                       2628 CJ Delft
%                                       The Netherlands
%
% Cris Luengo, April 2000.
% 30 June 2000: On binary images, we now do not(a)
% 15 November 2002: Fixed binary images to work in MATLAB 6.5 (R13)
% 10 March 2008: Fixed bug. COMPUTE1 has a new PHYSDIMS input parameter.
% 10 September 2009: Works on tensor images also.

function in = uminus(in)
for ii=1:prod(imarsize(in))
   try
      if strcmp(in(ii).dip_type,'bin')
         [tmp,dims,out_type,out_phys] = do1input(in(ii));
         %#function not
         in(ii) = compute1('not',tmp,dims,'bin',out_phys);
      else
         in(ii) = compute1('uminus',in(ii));
      end
   catch
      error(di_firsterr)
   end
end
