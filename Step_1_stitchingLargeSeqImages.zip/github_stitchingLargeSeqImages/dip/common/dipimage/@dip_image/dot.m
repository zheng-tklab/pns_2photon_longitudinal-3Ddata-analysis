%DOT   Dot product of two vector images.
%   DOT(A,B) returns the dot product of the vector images A and B.
%   If both A and B are column vectors, this is the same as A'*B.
%   The dot product results in a scalar image.
%
%   Either A or B can be a normal vector such as [1,0,0].
%
%   See also: INNER, OUTER, CROSS

% (C) Copyright 1999-2009               Pattern Recognition Group
%     All rights reserved               Faculty of Applied Physics
%                                       Delft University of Technology
%                                       Lorentzweg 1
%                                       2628 CJ Delft
%                                       The Netherlands
%
% Cris Luengo, December 2009.

function out = dot(in1,in2)
if di_isdipimobj(in1)
   if ~isvector(in1)
      error('Input images must be vectors.');
   end
   in1 = in1(:);
   sz1 = max(imarsize(in1));
else
   if ~isnumeric(in1)
      error('Illegal input class.');
   end
   sz1 = size(in1);
   if sum(sz1>1)>1
      error('Input data must be vectors.');
   end
   in1 = in1(:);
   sz1 = max(sz1);
end
if di_isdipimobj(in2)
   if ~isvector(in2)
      error('Input images must be vectors.');
   end
   in2 = in2(:);
   sz2 = max(imarsize(in2));
else
   if ~isnumeric(in2)
      error('Illegal input class.');
   end
   sz2 = size(in2);
   if sum(sz2>1)>1
      error('Input data must be vectors.');
   end
   in2 = in2(:);
   sz2 = max(sz2);
end
if sz1~=sz2
   error('Input vectors must have the same length.');
end
out = in1'*in2;
