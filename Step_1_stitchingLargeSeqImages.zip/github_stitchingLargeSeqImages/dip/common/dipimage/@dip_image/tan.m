%TAN   Tangent.
%  TAN(B) is the tangent of the pixels of B.

% (C) Copyright 1999-2000               Pattern Recognition Group
%     All rights reserved               Faculty of Applied Physics
%                                       Delft University of Technology
%                                       Lorentzweg 1
%                                       2628 CJ Delft
%                                       The Netherlands
%
% Cris Luengo, May 2000.

function out = tan(in)
try
   out = compute1('tan',in);
catch
   error(di_firsterr)
end
