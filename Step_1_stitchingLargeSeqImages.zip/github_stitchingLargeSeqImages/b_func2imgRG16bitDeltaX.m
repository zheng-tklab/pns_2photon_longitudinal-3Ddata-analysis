
%% {hongwei.zheng,kuner}@uni-heidelberg.de
%% Kuner LAB

function  b_func2imgRG16bitDeltaX(numList, dataSeq_name1, dataSeq_name3, writeSeq_name,deltaX, deltaY,imageTypeNumber)

addpath('./')
addpath ('./dip/Linuxa64/lib');
addpath ('./dip/common/mlv7_9/');
addpath ('./dip/common/mlv7_9/diplib/');
addpath ('./dip/common/dipimage/')
dip_initialise

savepath

addpath(genpath('./'));
addpath(genpath('./Linuxa64/lib'));
addpath(genpath('../'));
%%

seq_name1 = dataSeq_name1;
seq_name3 = dataSeq_name3;

number_list = numList;      
    tic
    
    switch imageTypeNumber
        case 1
    image_type = '.tif';   %'_ch00.tif'
        case 2
    image_type = '.ome.tif';
    end
    
    spaces = 4;     % 3 for 000
    opt = sprintf('%%0%dd', spaces);
    interlaced =0;
   
   index = sprintf(opt, number_list(1));
   first = sprintf('%s%s%s', seq_name1, index, image_type);   % %s%s.%s
    duration = length(number_list);

for nbri = 1:1:duration    %:-1:2
  seq = number_list(nbri);

  %   first = sprintf('%s%s%s',seq_name,sprintf(opt,seq),image_type);
  next1  = sprintf('%s%s%s',seq_name1, sprintf(opt,seq), image_type);
  next3  = sprintf('%s%s%s',seq_name3, sprintf(opt,seq), image_type);
  
  
  a = imread(next1)./16;  %16%imview(I1);
  b = imread(next3)./16;  %16

  fprintf(1,'\number of image in sequences %s...\n',next1);


a = dip_image(a,'dfloat');
b = dip_image(b,'dfloat');
sz = imsize(a);
ca= [sz(1)-50  sz(2)/2];
cb= [deltaX-50  sz(2)/2+deltaY];

% ca = ca1; %C1C3c5c7, mouse50206 small
% cb = cb1;


s = ca - (cb+[sz(1),0]);

% Extend images -- assuming [a,b] is the general alignment
z = newim(sz);
a = iterate('cat',1,a,z);
b = iterate('cat',1,z,b);
% Align images
b = iterate('dip_wrap',b,s);

% Crop images

if s(2)>0
   a = a(:,s(2):imsize(a,2)-1);
   b = b(:,s(2):imsize(b,2)-1);
else
%    a = a(:,0:imsize(a,2)-s(2)-1);
%    b = b(:,0:imsize(b,2)-s(2)-1);
end



d = (abs(a-b));        % for gray 8bit and 16bit images
d(0:sz(1)-1+ s(1),:) = 0;
d(sz(1):imsize(d,1)-1,:) = 0;
% writeim(d, sprintf('%s%s%s',seq_name77,sprintf(opt,seq),'_C13C57diff.jpg'),'jpeg')


% Seeds image
c = newim(d,'sint16');
c(0:sz(1)+s(1),:) = 1;
c(sz(1)-1:imsize(d,1)-1,:) = 2;

% Ordered region growing -- more or less the same as watershed + graph cut
c = dip_growregions(c,d,[],1,0,'high_first');
w = c==2;


% Compose
out = a;
out(w) = b(w);
out = uint16(round(a*16)); 
out(w)= uint16(round(b(w)*16));

seq_name777 = writeSeq_name;
imwrite(out,sprintf('%s%s%s',seq_name777,sprintf(opt,seq),'.tif'),'tiff');

toc
end 