%% {hongwei.zheng,kuner}@uni-heidelberg.de
%% TKuner LAB
%

function  func_write_mip_incre(write_folder,path2,path3)
%%      func_write_mip(write_folder,write_name,path2,path3 );
addpath(write_folder);
imSeq = dir([write_folder, '*c*']);
duration = numel(imSeq);
%write_name='./SNI/MIP_result/';
write_path='./MIP_result_vol3_kuner_incr/';
mkdir(write_path);
for ii = 1:1:duration-1
     currentImName = imSeq(ii).name;
     currentIm = imread(currentImName);
     V1(:,:,ii)=currentIm;
     im1 = max(V1, [],3);  
      imwrite(im1, sprintf('%s%s%s%s%s%s',write_path, 'MIP_xy_',path2,'_',path3, '.tif'));
      
   %%  imwrite(imsum, sprintf('%s%s%s%s%s%s',write_name2, 'sum_',path2,'_',path3,'.tif'));
   
end
