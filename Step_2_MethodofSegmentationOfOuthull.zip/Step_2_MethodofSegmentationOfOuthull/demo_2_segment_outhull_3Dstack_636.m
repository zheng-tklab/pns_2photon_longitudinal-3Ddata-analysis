%% {hongwei.zheng,kuner}@uni-heidelberg.de
%% TKuner LAB
%

clear all; close all;
label_list = [40:10:360, 360:20:500];
load label.mat;
path_label =' /Mice_636_TauGFP_naive/3rd/450/';
path1 ='/home/zheng/Vol3_Kuner/Vijay/SNI/';
path2 ='Mice_636_TauGFP_naive';
path3 = '3rd';
func_removeHull_MIP3_tc(label_list, path1, path2, path3, path_label);
