%% {hongwei.zheng,kuner}@uni-heidelberg.de
%% TKuner LAB
%

close all
clear all
clc

levels_num=3;
active_levels_num=1;


% % 
img_name ='.\labelSeg\o_d\segc1357_195.tif';
scribs_img_name ='.\labelSeg\o_d\segc1357_195_m.tif';
write_name =' segc1357_195_label.tif';
runMatting_neuro
imwrite(alpha, sprintf('%s',write_name, '.tif'));

% img_name ='.\labelSeg\o_d\segc1357_235.tif';
% scribs_img_name ='.\labelSeg\o_d\segc1357_235_m.tif';
% write_name =' segc1357_235_label.tif';
% runMatting_neuro
% imwrite(alpha, sprintf('%s',write_name, '.tif'));
% 
