
close all
clear all
clc

levels_num=3;
active_levels_num=1;

% img_name ='.\neurodata\C1357_453.jpg';  %not good directly on original
% image
% scribs_img_name ='.\neurodata\C1357_453_1.jpg';

img_name ='.\m40806small_label\m408smallsgc1357_103.tif';
scribs_img_name ='.\m40806small_label\m408smallsgc1357_103_m.tif';
write_name ='m408smallsgc1357_103_label';
runMatting_neuro
imwrite(alpha, sprintf('%s',write_name, '.tif'));
