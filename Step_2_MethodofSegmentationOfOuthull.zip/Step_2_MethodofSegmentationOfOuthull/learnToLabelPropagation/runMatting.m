
if (~exist('thr_alpha','var'))
  thr_alpha=[];
end
if (~exist('epsilon','var'))
  epsilon=[];
end
if (~exist('win_size','var'))
  win_size=[];
end

if (~exist('levels_num','var'))
  levels_num=1;
end  
if (~exist('active_levels_num','var'))
  active_levels_num=1;
end  

I=double(imread(img_name))/255;
mI=double(imread(scribs_img_name))/255;
consts_map=sum(abs(I-mI),3)>0.001; % draw lines become in clear homogeneous prior info.

if (size(I,3)==3) % color
  consts_vals=rgb2gray(mI).*consts_map;
end
if (size(I,3)==1) %gray
  consts_vals=mI.*consts_map; % drawling become bisection info. for foreground and background become 
end

%call function
alpha=solveAlphaC2F(I,consts_map,consts_vals,levels_num,active_levels_num,thr_alpha,epsilon,win_size);

figure, imshow(alpha); title('alpha');
drawnow;

% call function
[F,B]=solveFB(I,alpha);

figure, imshow([F]); title('F.');
figure, imshow([B]); title('B.');
figure, imshow(1-alpha); title('1-alpha.');
if (size(I,3)==3)
  figure, imshow([F.*repmat(alpha,[1,1,3]), B.*repmat(1-alpha,[1,1,3])]);
  title ('color alphaF');
end
if (size(I,3)==1)
  figure, imshow([F.*repmat(alpha, [1,1,1]), B.*repmat(1-alpha,[1,1,1])]);
  title('gray alphaF');
end
