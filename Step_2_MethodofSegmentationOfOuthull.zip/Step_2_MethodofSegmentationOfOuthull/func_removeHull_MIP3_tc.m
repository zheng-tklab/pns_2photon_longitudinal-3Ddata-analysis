%% {hongwei.zheng,kuner}@uni-heidelberg.de
%% TKuner LAB
%

function func_removeHull_MIP3_tc(label_list, path1, path2, path3, path_label)


path = strcat(path1, path2,'/', path3,'/');


if ~isempty(dir(strcat(path_label, 'tc1234_*')))
    label_name =  strcat(path_label, 'tc1234_');
elseif ~isempty(dir(strcat(path_label, 'tc_*')))
     label_name =  strcat(path_label, 'tc_');
else 
    label_name =  strcat(path_label, 'tc1357_');
end
%mkdir(strcat(path_label,'computed'));
%seq_data =      strcat(path, 'c1234/c1234_');

if ~isempty(dir( strcat(path, '1800/c1234_*')))
    seq_data    =strcat(path, '1800/c1234_');
else
    %%  fsprintf('no data');
 seq_data =      strcat(path, 'c1234/c1234_');

end
path22= pwd;
path_write =strcat(path22,'./results/nohullStack/');   
mkdir(path_write);
pathw= strcat(path_write, path2,'/', path3,'/');
write_folder=  strcat(pathw, 'nohull_bit16/');
mkdir(write_folder);

write_name =  strcat(write_folder, 'c1234_new_');
numberOfLabels= length(label_list);
spaces =4;
opt = sprintf('%%0%dd', spaces);

for ii = 1: 1: 2
     index1=  label_list(ii);
     index2 = label_list(ii+1);
  for  number_list = (index1): 1: (index2) %%%%%(index2-(index2-index1))
       [J1]= fun_outerhull_label_noSeg_clean_incre(number_list,index1, index2, path_label,label_name, seq_data, write_name, spaces);
   end
end


for ii =2: 1: numberOfLabels-1
   index1=  label_list(ii);
   index2 = label_list(ii+1);
  for  number_list = (index1-ceil((index2-index1)/2))+1: 1: (index2-ceil((index2-index1)/2))
       [J1]= fun_outerhull_label_noSeg_clean_incre(number_list,index1, index2, path_label,label_name, seq_data, write_name, spaces);
   end
end
func_write_mip_incre(write_folder,path2,path3 );



