%% {hongwei.zheng,kuner}@uni-heidelberg.de
%% TKuner LAB
%

function  [J1]=fun_outerhull_label_noSeg_clean_fill(number_list, index1, index2, path_label, label_name, seq_data, write_name, spaces)
    
    image_type = '.tif';    %'_ch00.tif'
    image_type2 = '.tif';   %'_ch00.tif'
    spaces =4;
    opt = sprintf('%%0%dd', spaces);
    interlaced =0;
    index = sprintf(opt, number_list);
    
    write_label =strcat(path_label, 'computed','/');
    mkdir(write_label);
      
    seq_label1 = sprintf('%s%s%s', label_name, sprintf(opt, index1),'.tif');
    seq_label2 = sprintf('%s%s%s', label_name, sprintf(opt, index2),'.tif');    
    seq_name2=seq_data;
    seq_name= seq_label1;
        
    first = sprintf('%s%s%s', seq_name, index, image_type);   % %s%s.%s
    duration = length(number_list);

    
%%
for nbri = 1:1:duration %:-1:2
    
  seq = number_list(nbri);
  next2  = sprintf('%s%s%s',seq_name2, sprintf(opt,seq), image_type2);
  fprintf(1, '\number of image in sequences %s...\n',next2);

    if ischar(seq_name)
       L1=imread(seq_label1);
    end
   
   L1_label = func_compute_label(L1);   
   
 imwrite(L1_label, sprintf('%s%s%s%s',write_label,'tc1357_',sprintf(opt, index1),'.tif')); 
   
   Iobrcbr2= im2bw(255-L1_label);
   Iobrcbr2 = imresize(Iobrcbr2, [1800 1800]);
   
   I2 = imresize( imread(next2), [1800 1800]);   
   J1 = immultiply(I2, Iobrcbr2);
   imwrite(J1, sprintf('%s%s%s',write_name,sprintf(opt,seq),'.tif')); 
  
end

%%

   