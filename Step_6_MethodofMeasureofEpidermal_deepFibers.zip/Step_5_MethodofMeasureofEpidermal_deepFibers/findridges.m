%%% {hongwei.zheng,kuner}@uni-heidelberg.de
%%% TKuner LAB
%
%%

function [Out] = findridges(S,T1, T2, sigmay) 

%[L1,a, Out1, Out2] = findridges(S) 
% rotate the reference filter from 0 to 180 degrees
angleVec = 0:5:180;

%vary the scale from 1 to 5 
%% ScaleVec =  [0.5 1 1.5 2 2.5 ]; orginal
ScaleVec =  [0.5 1 1.5 2 2.5 3 3.5 4 4.5 5];       %%% zhw add

[m n] = size(S);

%Keep sigmay fixed
%sigmay = 5;

for scaleIdx = 1:length(ScaleVec)
    sigmax = ScaleVec(scaleIdx);

    [x,y] = meshgrid(-6*sigmax:6*sigmax);

    Currentfilter =  exp(-((x.^2)/(sigmax^2) + (y.^2)/(sigmay^2))/2)...
                                  .*(1/(pi*sigmax^4)).*(1 - ((x.^2)/(2*sigmax^2)));

    Currentfilter = Currentfilter/sum(sum(Currentfilter));

    idx = find(abs(Currentfilter) > 1e-5);
    %idx = find(abs(Currentfilter) > 0);
    
    avgresp = sum(Currentfilter(idx))/length(idx);

    Currentfilter(idx) = Currentfilter(idx) - avgresp;
    reffilter{scaleIdx} = -Currentfilter;

    %figure,imagesc(reffilter{scaleIdx})

end

filter = cell(length(ScaleVec), length(angleVec));

for scaleIdx = 1:length(ScaleVec)
    for orientIdx = 1:length(angleVec)
        filter{scaleIdx,orientIdx} = imrotate(reffilter{scaleIdx},angleVec(orientIdx),'bilinear','crop');
    end
end

%%
val  = zeros(m,n,3);
Out = zeros(m,n);

for scaleIdx = 1:length(ScaleVec)
    for orientIdx = 1:length(angleVec)
        val(:,:,orientIdx) = imfilter(S,filter{scaleIdx,orientIdx});
    end
    
    [OrientOut(:,:,scaleIdx) MaxOrientIdxVec(:,:,scaleIdx)] = max(val,[ ],3);
end
[Out MaxScaleIdxVec] = max(OrientOut,[],3);

%%

MaxScale = MaxScaleIdxVec;

for i = 1:m
    for j = 1:n
        MaxOrient(i,j) = MaxOrientIdxVec(i,j,MaxScaleIdxVec(i,j));
    end
end

%OrientOut(:,:,MaxScale) = ScaleVec(MaxScaleIdxVec);

%%%%%Out = Out - min(Out(:));    % sometimes get matrix dimension error

%alternativ
bw = findhysthresh(Out,T1, T2);
OutT=findgetThining(bw);  %     figure(6), imshow(bw); title('bw');
Out=OutT.*Out;                   %   figure(7), imshow(Out); title('Out');

%imwrite (Out, sprintf('%s%s', i1n,'edge_orig.tiff' ));

% Outbg = imresize(Out,2);        %figure, imshow(Out1); title(' Out1, i1resize smooth');
% 
% Out2 = imresize(Outbg,0.5);   %figure, imshow(Out2); title('Out2, i1resize smooth');

%%

% [im,location] = nonmaxsup(Out, MaxOrient+90, 1.5);
% a=MaxOrient;
% a=(a*10)*(pi/180);
% a=a-pi/2;
% 
% imBin = im;
% 
% imBin(find(imBin < 0.1*max(imBin(:)))) = 0;
% imBin(find(imBin > 0)) = 1;
% 
% L = bwlabel(imBin, 8);
% 
% for i = 1:max(L(:))
%     idx = find(L == i);
%     %avg(i) = sum(im(idx))/length(idx);
%     %avg(i) = max(im(idx));
%     avg(i) = length(idx);
% end
% 
% [sortavg sortIdx] = sort(avg,'descend');
% 
% L1 = zeros(m,n);
% 
% for i = 1:round(max(L(:))/3)
% L1(find(L == sortIdx(i))) = im(find(L == sortIdx(i)));
% end
% % 
% 
