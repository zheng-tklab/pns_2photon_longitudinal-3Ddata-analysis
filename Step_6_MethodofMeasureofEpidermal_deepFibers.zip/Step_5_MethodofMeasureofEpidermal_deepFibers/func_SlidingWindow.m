%%% {hongwei.zheng,kuner}@uni-heidelberg.de
%%% TKuner LAB
%
%%

function [ o_image ] =func_SlidingWindow( i_image, i_padSize, i_fun, i_options )%, i_windowShape, i_mask )
%SLIDINGWINDOW Summary of this function goes here
%   Detailed explanation goes here

o_image = zeros(size(i_image,1),size(i_image,2),size(i_image,3));
i_image = padarray(i_image,i_padSize,'symmetric');
i_padSize = num2cell(i_padSize);
[m,n,p] = deal(i_padSize{:});
[row,col,depth] = size(i_image);

for i = m+1:row-m
    for j = n+1:col-n
        for h = p+1:depth-p
            ii = i-m;
            jj = j-n;
            hh = h-p;
            temp = i_image(i-m:i+m,j-n:j+n, h-p:h+p);
            o_image(ii,jj,hh) = feval(i_fun, temp, i_options.windowShape, i_options.mask);
        end
    end
end

end