%%% {hongwei.zheng,kuner}@uni-heidelberg.de
%%% TKuner LAB
%
%%

function [Bm]= func_RandomSamp_MultiCrop_epidermal_deepfiber_count_entire(path1, pathm, imgName)
%func_RandomSamp_MultiCrop_epidermal_deepfiber_count(path1, pathm, T1, T2, sigmay,txtfile,txtLength,txtNum, imgName)

i3 = 'pure_2020_May5_6_w'; 
resPath = strcat(path1, i3, '\');
mkdir(resPath);

 i2s = strcat(resPath, num2str(imgName),'_crop_');
 
 FileTif= pathm;
 InfoImage=imfinfo(FileTif);
 duration2=length(InfoImage);
 
 mImage = InfoImage(1).Width;
 nImage = InfoImage(1).Height;
 V1=zeros(nImage, mImage, duration2, 'uint8');
%   imread(pathm);
%  orim  = imresize( uint8(())),0.5);                          
%  figure(1), imshow(orim); title('orim');
%  orim = medfilt2(orim);

imgType = '.tif';


fileIDNum6= fopen(strcat(resPath, '_number of TerminalsAll a+b','.dat'), 'a+'); 
fprintf(fileIDNum6, '%s%s:, %s, %s, %s, %s,  %s,  %s, %s,  %s,  %s \n', 'imgName', '_measure','i','j', 'numOb','numEpidermal', 'voxelSize', 'all_terminals', 'terminalLength', 'density_all','density_Epid' );


%             
for number_list = 1: duration2
     im = imread(FileTif,number_list, 'Info',InfoImage); %%figure(1);  imshow(im); title('im');
     % orim = medfilt2(im);
     imwrite (im, sprintf('%s%s%s%s%s%s',  resPath, imgName,'_', imgType), 'WriteMode', 'append');
   %  figure(1), imshow(im), title('im');
      im1 = medfilt2(im);
                    se1= strel('disk',1);   
                    Bm1= medfilt2(im1);
                    Ie1 = imerode(Bm1, se1); 
                    Iobr1 = imreconstruct(Ie1,Bm1 );
                    Iobrd1 = imdilate(Iobr1, se1); 
                    Iobrcbr1 = imreconstruct(imcomplement(Iobrd1), imcomplement(Iobr1));
                    Iobrcbr1 = imcomplement(Iobrcbr1);
                   % im2= uint8( im2bw(Iobrcbr1, 0.1)*255);  
                    im1sp    =medfilt2(Iobrcbr1);
      
                    se4Size =6;
                    se4 = strel('disk', se4Size);   
                    Bm1= medfilt2(im1);
                    se2 = strel('disk', 2);
                    Bm1 = imdilate(Bm1, se2);
                    Ie1 = imerode(Bm1, se4); 
                    Iobr1 = imreconstruct(Ie1,Bm1 );
                    Iobrd1 = imdilate(Iobr1, se4); 
                     %%% %%figure(1), imshow(Iobrd1); title('Iobrd')
                    Iobrcbr1 = imreconstruct(imcomplement(Iobrd1), imcomplement(Iobr1));
                    Iobrcbr1 = imcomplement(Iobrcbr1);
                    Bm2fb=medfilt2(Iobrcbr1);
                  
                    V1s(:,:,number_list)  = im2bw(im1sp,0.2);
                    V2f(:,:,number_list)  = im2bw(Bm2fb,0.2);
      
                    imwrite (Bm2fb, sprintf('%s%s%s%s', resPath,  imgName, '_noSpineStack_', imgType), 'WriteMode', 'append');
                    imwrite (im1sp, sprintf('%s%s%s%s', resPath,  imgName, '_withSpineStack_', imgType), 'WriteMode', 'append');
    
  
end
     max_V1s   = max(V1s, [],3) ;
     %figure(1), imshow(max_V1s), title('max_V1s');
     imwrite (max_V1s , sprintf('%s%s%s%s%s%s%s',  resPath, imgName,'_','max_V1s', imgType));
    % save( sprintf('%s',imgName,'V1.mat') );
     V1_temp = V1s;
     
     V1_coronal = permute(V1_temp,[2,3,1]);
     mip1_coronal = max(V1_coronal, [],3);
     figure(2), imshow(mip1_coronal); title('mip1_coronal');
     imwrite (mip1_coronal, sprintf('%s%s%s%s%s%s%s',  resPath, imgName,'_','mip1_coronal', imgType));
     
     V1_sagittal = permute(V1_temp,[3,1,2]);
     mip1_sagittal = max(V1_sagittal, [],3);
     figure(3), imshow(mip1_sagittal); title('mip1_sagittal');
     imwrite (mip1_sagittal, sprintf('%s%s%s%s%s%s%s',  resPath, imgName,'_','mip1_sagittal', imgType));
     
         
    [ww,hh,zz] = size(V1)
            
%% ======
%densityList = [ ];
divideW = 1;
divideH = 1;
w1 = size(im,1)/divideW; 
h1 = size(im,2)/divideH;
Bm = ones(size(im));
    
delta= w1/3;
for i = 1:1:divideW
for j = 1:1:divideH      
    
%        for delta = [1,w1/2]
%          V_crop =  V1((i-1)*w1+delta: i*w1,(j-1)*h1+delta:j*h1, 1:zz);
%        end  
        V1s_crop =  V1s((i-1)*w1+1:i*w1,(j-1)*h1+1:j*h1, 1:zz);
        V2f_crop =  V2f((i-1)*w1+1:i*w1,(j-1)*h1+1:j*h1, 1:zz);
%          sizeIn = size(V_crop);
%          hFigOriginal = figure;
%          hAxOriginal  = axes;
%          slice(double(V_crop),sizeIn(2)/2,sizeIn(1)/2,sizeIn(3)/2);
%          grid on, shading interp, colormap gray
% 
%          B = imrotate3(V_crop,90,[0 0 1],'nearest','loose','FillValues',0);
%          figure
%          slice(double(B),sizeIn(2)/2,sizeIn(1)/2,sizeIn(3)/2);
%          grid on, shading interp, colormap gray
  
         max_V1s_crop   = max(V1s_crop, [],3);
         %figure(2), imshow(max_V_crop); title('max_V_crop');
         imwrite (max_V1s_crop, sprintf('%s%s%s%s%s%2d%2d%s',  resPath, imgName,'_','max_V1s_crop','_',i, j, imgType));
         
       for ii = 1:zz
         im_crop = V1s_crop(:,:,ii); 
        % figure(2), imshow(im_crop); title('I_crop');
         imwrite ( im_crop, sprintf('%s%s%s%2d%2d%s', resPath, imgName,'_',i, j, imgType), 'WriteMode', 'append');   
       end
       
       V1s_crop_coronal = permute(V1s_crop,[2,3,1]);
       mip_crop_coronal = imrotate( max(V1s_crop_coronal, [],3), -90);
       %figure(3), imshow(mip_crop_coronal);title('(mip_crop_coronal);');
       imwrite (mip_crop_coronal, sprintf('%s%s%s%s%s%2d%2d%s',  resPath, imgName,'_','mip_spineall_crop_coronal','_',i, j, imgType));
      
        
       V1s_crop_sagittal = permute(V1s_crop,[3,1,2]);
       mip_crop_sagittal = imrotate(  max(V1s_crop_sagittal, [],3), -90);
      % figure(4), imshow(mip_crop_sagittal);title('mip_crop_sagittal');
       imwrite (mip_crop_sagittal, sprintf('%s%s%s%s%s%2d%2d%s',  resPath, imgName,'_','mip_crop_sagittal','_',i, j, imgType));
       
       
            [xs,ys,zs] =size(V1s_crop);
            se3d  = strel('ball', 2, 4); 
            se3d2 = strel('ball', 3, 5);
            V_sp2 = imdilate (uint8(V1s_crop*255), se3d) ; 
            V_fb2 = imdilate (uint8(V2f_crop*255), se3d2) ; 
           %%V_sp2 = imdilate (uint8(V_sp*255), se3d) ;     %%%%imdilate(image3D, ones(d_row, c_col, d_grey));
            CC = bwconncomp(V_sp2);                                   % get all particles
            numPixels = cellfun(@numel,CC.PixelIdxList);
            [idx_small_all]= find([numPixels] <3);                   %mean([numPixels]
             %BW_big = ismember(V2, idx_big); 
             duration = length([idx_small_all]);
            for k = 1: duration
                kk = idx_small_all(k);
                  %  areas_in_pixels(kk)=length(CC.PixelIdxList{k});
                  % areas_in_pixels(kk)=length(CC.PixelIdxList{kk});
                idx =CC.PixelIdxList{kk};
                V_sp2(idx) =0;
            end
            CC2 = bwconncomp(V_sp2);  
       %%
            max_im2f   = max(V_fb2, [],3);
            max_im1    = max(V_sp2, [],3);
            
            rgbfibSpDilat3D(:,:,1) = max_im2f;
            rgbfibSpDilat3D(:,:,2) = max_im1;
            rgbfibSpDilat3D(:,:,3) = zeros(xs, ys);
            imwrite (rgbfibSpDilat3D, sprintf('%s%s%s%s%2d%2d%s%s', resPath, 'mip_', imgName,'_',i, j, '_rgbfibSpDilat3D','.tif' ), 'tiff'); 
            
        
             for i2 = 1:zs
                Iv1 = V_sp2(:,:,i2);
                %%figure(4); imshow(Iv1); title('after modify1');
                imwrite (Iv1, sprintf('%s%s%s%2d%2d%s%s', resPath, imgName,'_',i, j, '_withSpineStack_AfterDilate3D_', imgType), 'WriteMode', 'append');
             end
            
                     
%%  count the number of spines and volume of all spines, label the spines
      
            V_delta = V_sp2 -V_fb2;
            CC3 = bwconncomp(V_delta);                        % get all particles
            numPixels = cellfun(@numel,CC3.PixelIdxList);
            [biggest,idx] = max(numPixels);
            %[idx_big]= find( [numPixels] > mean([numPixels]));
            [idx_small_all]= find([numPixels] <3); %mean([numPixels]
            %BW_big = ismember(V2, idx_big); 
            [xd,yd,zd] =size(V_delta);
             V_onlySp= V_delta;
            duration = length([idx_small_all]);
            for k = 1: duration
                kk = idx_small_all(k);
                  %  areas_in_pixels(kk)=length(CC.PixelIdxList{k});
                  % areas_in_pixels(kk)=length(CC.PixelIdxList{kk});
                idx =CC3.PixelIdxList{kk};
                V_onlySp(idx) =0;
            end
            
            CC4 = bwconncomp(V_delta>1);
            numOb = CC4.NumObjects;
            numPixels2 = cellfun(@numel,CC4.PixelIdxList);
%             for i = 1:zd
%                  imSp1 = V_onlySp(:,:,i);
%                  %%figure(4); imshow(imSp1); title('only Spine');
%                 imwrite (imSp1, sprintf('%s%s%s%s', resPath, imgName, '_withSpineStack_onlySpine', imgType), 'WriteMode', 'append');
%             end
            
%%

 %%
    threshold = 10;
    testvol = V_onlySp(:,:,1:zd)>threshold;
    %testvol = V_onlySp;

       for ii2=size(testvol,3):-1:1
           testvol(:,:,ii2) = imfill(testvol(:,:,ii2),'holes');
       end

    %skel1=padarray(testvol,[1 1 1]);
    skel = Skeleton3D(testvol);
    col=[0 .9 0];
    hiso   = patch(isosurface(testvol,0),'FaceColor',col,'EdgeColor','none');
    hiso2 = patch(isocaps(testvol,0),'FaceColor',col,'EdgeColor','none');
    axis equal;axis off;
    lighting phong;

    isonormals(testvol,hiso);
    alpha(0.5);
    set(gca,'DataAspectRatio',[1 1 1])
    camlight;
    hold on;
    w=size(skel,1);
    l  =size(skel,2);
    h =size(skel,3);
    [x,y,z]=ind2sub([w,l,h],find(skel(:)));
    plot3(y,x,z,'square','Markersize',2,'MarkerFaceColor','r','Color','r');    
    %%skelLength = size(skel(:),1) 
    skelLength2 = size(find(skel(:))>0,1)
    set(gcf,'Color','white');
    view(180,85)

%% skel2grap

%% skel2grap

w = size(skel,1);
l  = size(skel,2);
h = size(skel,3);

% convert skeleton to graph structure
[A,node,link] = Skel2Graph3D(skel,4);

% convert graph structure back to (cleaned) skeleton
skel2 = Graph2Skel3D(node,link,w,l,h);

% iteratively convert until there are no more 2-nodes left
[A2,node2,link2] = Skel2Graph3D(skel2,4);
% while(min(cellfun('length',{node2.conn}))<3)
%     skel2 = Graph2Skel3D(node2,link2,w,l,h);
%     [A2,node2,link2] = Skel2Graph3D(skel2,4);
% end;
% display result
hold on;

numberOfBranches=0;
numberOfjunctions =0;

for i2=1:length(node2)
    x1 = node2(i2).comx;
    y1 = node2(i2).comy;
    z1 = node2(i2).comz;
    for j2=1:length(node2(i2).links)    % draw all connections of each node
        if(node2(i2).conn(j2)<1)
            col='b'; % branches are blue
        else
            col='r'; % links are red
        end
        
        % draw edges as lines using voxel positions
        for k=1:length(link2(node2(i2).links(j2)).point)-1            
            [x3,y3,z3]=ind2sub([w,l,h], link2(node2(i2).links(j2)).point(k));
            [x2,y2,z2]=ind2sub([w,l,h], link2(node2(i2).links(j2)).point(k+1));
            line([y3 y2],[x3 x2],[z3 z2],'Color',col,'LineWidth',3);
        end
    end
    
    % draw all nodes as yellow circles
    plot3(y1,x1,z1,'o','Markersize',9,  'MarkerFaceColor','y', 'Color','k');
    
end
numberOfBranches = numel(node2)+2;
numberOfjunctions = numel(node2);

axis image;axis off;
set(gcf,'Color','white');
drawnow;
%%view(180,90)
%view(-17,46);
%%close all;
savefig(sprintf('%s%s%s%2d%2d%s',resPath, imgName,'_',i,j,'.fig'));
print('-dtiff','-r300',sprintf('%s%s%s%2d%2d%s',resPath, imgName,'_',i,j,'.tif'));

all_terminals = numOb+numberOfBranches;
density_all  =all_terminals / skelLength2*100;

density_Epid  = numberOfBranches / skelLength2*100;

fprintf(fileIDNum6, '%s%s:, %2d, %2d, %10.4f, %10.4f, %10.4f,  %10.4f, %10.4f, %10.4f, %10.4f \n', imgName,'_measure',i,j, numOb, numberOfBranches, sum(numPixels2), all_terminals, skelLength2, density_all,density_Epid );

close all;
              
              
  end    
end
