
%%
%%% {hongwei.zheng,kuner}@uni-heidelberg.de
%%% TKuner LAB
%
%%
close all; clear all; clc; 
txtfile =   'sT_138_3tibial_multiEpidermal_density.txt';
txtLength=  'sT_138_3tibial_multiEpidermal_length.txt';
txtNum =    'sT_138_3tibial_multiEpidermal_NumTerminals.txt';

path1='.\snstdTomato_138n\3rd\cv\bit8\';
p_base       = dir([path1,'*.tif']);
duration   = length(p_base);
number_list=1:1:length(p_base);
for ii=1: 1: duration
seq = number_list(ii);
dataSeq_name1=strcat(path1, p_base(ii).name);
fprintf(1,'number of image in sequences: %s\n',p_base(ii).name)
imgName= p_base(ii).name;
pathm=dataSeq_name1;
Bm = func_RandomSamp_MultiCrop_epidermal_deepfiber_count_w(path1, pathm, imgName);
close all; 
end
% 
% %%