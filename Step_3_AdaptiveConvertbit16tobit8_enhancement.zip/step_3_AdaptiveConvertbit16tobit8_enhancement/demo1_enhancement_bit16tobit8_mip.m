%%hongwei.zheng@uni-heidelberg.de
%%

im = imread('MAX_Mice_631_TauGFP_naive_3rd.tif');
im = imread('Mice_636_TauGFP_01_naive_3rd0092.tif');
figure, imshow(im); title('original');

%im = imread('5.png');
image2= func_he(im);
image2 = image2;
figure, imshow(image2);title('image2');
img3 = histeq(image2-mean(mean(image2)));
figure, imshow(img3); title('img3');

function image = func_he(image)

nChannel = size(image,3);
switch nChannel
    case 3 % RGB
        image = cat(3, histeq(image(:,:,1)),histeq(image(:,:,1)),histeq(image(:,:,1)));
    case 1 % gray
        image = histeq(image);
    otherwise
        for c = 1:nChannel
            image(:,:,c) = histeq(image(:,:,c));
        end
end
end

%%comparison with matlab function 
%%adapthisteq has CLAHE method inside
