%% hongwei.zheng@uni-heidelberg.de

%% Enhancemnet of different scanning layer in different depth.

%%% 0092 means that the depth is scanning layer 92 micron
%%% 0298  means that the depth is scanning layer 298 micron
 
imbit16 = imread('Mice_636_TauGFP_01_naive_3rd0092.tif');
%%% 0092 means that the depth is scanning layer 92 micron
figure, imshow(imbit16); title('original');

AInv16 = imcomplement(imbit16);
imshow(AInv16);

BInv16 = imreducehaze(AInv16);
imshow(BInv16);

B = imcomplement(BInv16);
montage({imbit16,B});

BInv = imreducehaze(AInv16, 'Method','approx','ContrastEnhancement','boost');
BImp = imcomplement(BInv);
figure, montage({imbit16, BImp});

% %%

imbit16 = imread('Mice_636_TauGFP_01_naive_3rd0298.tif');
%%% 0298  means that the depth is scanning layer 298 micron
figure, imshow(imbit16); title('original');

AInv16 = imcomplement(imbit16);
imshow(AInv16);

BInv = imreducehaze(AInv16,'ContrastEnhancement','none');
imshow(BInv);

B = imcomplement(BInv16);
montage({imbit16,B});

BInv = imreducehaze(AInv16, 'Method','approx','ContrastEnhancement','boost');
BImp = imcomplement(BInv);
figure, montage({imbit16, BImp});



